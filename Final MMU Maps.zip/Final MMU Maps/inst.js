var TheGraph = {
    "A" : { 
        "Coordinates" : [3776, 625],
        "Links" : {"C": 1}
    },
    "B" : { 
        "Coordinates" : [970, 910],
        "Links" : {"C" : 5, "G" : 5}
    },
    "C" : { 
        "Coordinates" : [3776, 910],
        "Links" : {"A" : 1, "B" : 5, "D" : 6, "J" : 6}
    },
    "D" : { 
        "Coordinates" : [6825, 910],
        "Links" : {"C" : 6, "E" : 1}
    },
    "E" : { 
        "Coordinates" : [6825, 740],
        "Links" : {"D" : 1, "F" : 2}
    },
    "F" : { 
        "Coordinates" : [7375, 740],
        "Links" : {"E" : 2}
    },
    "G" : { 
        "Coordinates" : [970, 3535],
        "Links" : {"B" : 5, "H" : 1}
    },
    "H" : { 
        "Coordinates" : [1290, 3535],
        "Links" : {"G" : 1, "I" : 5}
    },
    "I" : { 
        "Coordinates" : [1290, 5800],
        "Links" : {"H" : 5, "J" : 4, "K" : 1}
    },
    "J" : { 
        "Coordinates" : [3776, 5800],
        "Links" : {"C" : 6, "I" : 4, "L" : 4}
    },
    "K" : { 
        "Coordinates" : [1290, 6250],
        "Links" : {"I" : 1}
    },
    "L" : { 
        "Coordinates" : [3776, 8235],
        "Links" : {"J": 4}
    }
}


let shortestDistanceNode = (distances, visited) => {
    // create a default value for shortest
      let shortest = null;
      
        // for each node in the distances object
      for (let node in distances) {
          // if no node has been assigned to shortest yet
            // or if the current node's distance is smaller than the current shortest
          let currentIsShortest =
              shortest === null || distances[node] < distances[shortest];
              
            // and if the current node is in the unvisited set
          if (currentIsShortest && !visited.includes(node)) {
              // update shortest to be the current node
              shortest = node;
          }
      }
      return shortest;
  };

  let findShortestPath = (graph, startNode, endNode) => {
 
    // track distances from the start node using a hash object
    let distances = {};
    distances[endNode] = "Infinity";
    distances = Object.assign(distances, graph[startNode].Links);
   // track paths using a hash object
    let parents = { endNode: null };
    for (let child in graph[startNode].Links) {
     parents[child] = startNode;
    }
     
    // collect visited nodes
      let visited = [];
   // find the nearest node
      let node = shortestDistanceNode(distances, visited);
    
    // for that node:
    while (node) {
    // find its distance from the start node & its child nodes
     let distance = distances[node];
     let children = graph[node].Links; 
         
    // for each of those child nodes:
         for (let child in children) {
     
     // make sure each child node is not the start node
           if (String(child) === String(startNode)) {
             continue;
          } else {
             // save the distance from the start node to the child node
             let newdistance = distance + children[child];
   // if there's no recorded distance from the start node to the child node in the distances object
   // or if the recorded distance is shorter than the previously stored distance from the start node to the child node
             if (!distances[child] || distances[child] > newdistance) {
   // save the distance to the object
        distances[child] = newdistance;
   // record the path
        parents[child] = node;
       } 
            }
          }  
         // move the current node to the visited set
         visited.push(node);
   // move to the nearest neighbor node
         node = shortestDistanceNode(distances, visited);
       }
     
    // using the stored paths from start node to end node
    // record the shortest path
    let shortestPath = [endNode];
    let parent = parents[endNode];
    while (parent) {
     shortestPath.push(parent);
     parent = parents[parent];
    }
    shortestPath.reverse();
     
    //this is the shortest path
    let results = {
     distance: distances[endNode],
     path: shortestPath,
    };
    // return the shortest path & the end node's distance from the start node
      return results;
   };



const navSlide = () => {
    var counter = 0;
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.x');
    const f0B = document.getElementById('F0')
    const f1B = document.getElementById('F1')
    const f2B = document.getElementById('F2')
    const f3B = document.getElementById('F3')
    const f4B = document.getElementById('F4')
    var map = document.getElementById('map')
    var roomInf = document.getElementById('room')
    var destBut = document.getElementById('getD')
    var startEntry = document.getElementById('startL')
    var dir = document.getElementById('dir')
    var directionButton = document.getElementById('dirButton')
    var searchBar = document.getElementById('search')
    var sugWrapper = document.querySelector('.sug')
    var suggestions = sugWrapper.querySelector('div')
    
    searchBar.onkeyup = (e) => {
        suggestionList(e, 'suggestions-active', searchBar, 1)
        
    }

    burger.addEventListener('click', () => {
        nav.classList.toggle('nav-active');
    });

    destBut.addEventListener('click', () => {
        var heading = (document.getElementById('room-header')).innerHTML
        document.getElementById('Dest').value=heading;
        roomInf.classList.toggle('room-active');
        dir.classList.toggle('dir-active');
        
    })

    startEntry.onkeyup = (e) => {
        suggestionList(e, 'suggestions-active-dir', searchBar, 2)
       }

    directionButton.addEventListener('click', () =>{
        const lineString = new H.geo.LineString();
        var StaringPoint = (startEntry.value);
        var possRoutes = []; // stores the points
        var heading = (document.getElementById('Dest')).value
        heading = heading.substring(5); // gets the name of the room
        var Rooms = nestedRooms[heading[0]];//Rooms on the destination floor

        if (StaringPoint == 'Main Entrance' && heading[0] == 0){
            for (const x of (Rooms[heading][1])){
                possRoutes.push(findShortestPath(TheGraph, "A", x))
            } // finds the shorted path
            possRoutes.reduce(function(prev, curr) {
                possRoutes = ( prev.distance < curr.distance ? prev : curr);
            });
            
            displayRoute(possRoutes, heading, Rooms, 1)
        }else if (StaringPoint.substring(5)[0]==heading[0]){
            StaringPoint = StaringPoint.substring(5); // gets the name of the room
            for (const x of (Rooms[heading][1])){
                for (const y of (Rooms[StaringPoint][1])){
                    possRoutes.push(findShortestPath(TheGraph, y, x))
                }
            } // finds the shorted path
            possRoutes.sort(function(a, b) {
                return a.distance - b.distance;
              }); 
              
            displayRoute(possRoutes[0], heading, Rooms, StaringPoint)
        }else if (StaringPoint.substring(5)[0]!=heading[0] || (StaringPoint == 'Main Entrance' && heading[0] != 0)){
            if (StaringPoint == 'Main Entrance'){
                StaringPoint = "0.60"
                var RoomsS = nestedRooms[StaringPoint[0]];
                possRoutes = (findShortestPath(TheGraph, "A", "F"))
                
            }else{
                StaringPoint = StaringPoint.substring(5); // gets the name of the room
                var RoomsS = nestedRooms[StaringPoint[0]];
                for (const x of (RoomsS[StaringPoint][1])){
                    possRoutes.push(findShortestPath(TheGraph, "F", x))
                } // finds the shorted path
                possRoutes.reduce(function(prev, curr) {
                    possRoutes = ( prev.distance < curr.distance ? prev : curr);
                });
            }

            
            displayRoute(possRoutes, StaringPoint, RoomsS, 1)


            possRoutes = [];

            for (const x of (Rooms[heading][1])){
                possRoutes.push(findShortestPath(TheGraph, "F", x))
            } // finds the shorted path
            possRoutes.reduce(function(prev, curr) {
                possRoutes = ( prev.distance < curr.distance ? prev : curr);
            });
            
            displayRoute(possRoutes, heading, Rooms, 1)


            
        }
        
        
    })
        

    checkBtn(f0B, F0)
    checkBtn(f1B, F1)
    checkBtn(f2B, F2)
    checkBtn(f3B, F3)
    checkBtn(f4B, F4)

    map.addEventListener('click', () => {
        if(roomInf.classList.contains('room-active')==true && click == 0){
            roomInf.classList.toggle('room-active');
        }
        if(dir.classList.contains('dir-active')==true && click == 0){
            dir.classList.toggle('dir-active');
            
            lineString.eachLatLngAlt(eachFn);
        }
        if (suggestions.classList.contains('suggestions-active-dir')==true) {suggestions.classList.remove('suggestions-active-dir')}
        try{
            for(let i=0; i<LineStrings.length; i++){
                LineStrings[i][1].removeObject(LineStrings[i][0]);
            }
            if (click == 0){current.removeObject(roomMarker)}
        }catch(e){}
        click = 0;
        LineStrings.length = 0;
    })
    

}

function displayRoute(possRoutes, heading, Rooms, sameFloor){
    const lineString = new H.geo.LineString();
    lineString.eachLatLngAlt(eachFn);
    if (sameFloor!=1){
        var point = Object.assign({}, Rooms[sameFloor][0]);
        var distanceToOrigin = pythagorean(point[1], point[0])
        var ang = 1.5708-(angle + Math.atan(point[0]/point[1]))
        point[0] = originX-(Math.cos(ang)*distanceToOrigin)*scaleX
        point[1] = originY-(Math.sin(ang)*distanceToOrigin)*scaleY
        lineString.pushPoint({lat: point[0], lng: point[1]})
    }
    console.log(possRoutes)
    for (var cor in possRoutes.path){
        var point = (TheGraph[possRoutes.path[cor]].Coordinates) // gets the coordinate from the dictionary
        var point = Object.assign({}, point);
        var distanceToOrigin = pythagorean(point[1], point[0])//maths
        var ang = 1.5708-(angle + Math.atan(point[0]/point[1]))
        point[0] = originX-(Math.cos(ang)*distanceToOrigin)*scaleX
        point[1] = originY-(Math.sin(ang)*distanceToOrigin)*scaleY
        lineString.pushPoint({lat: point[0], lng: point[1]}) // adds the point to the map
    }
    var point = Object.assign({}, Rooms[heading][0]);
    var distanceToOrigin = pythagorean(point[1], point[0])
    var ang = 1.5708-(angle + Math.atan(point[0]/point[1]))
    point[0] = originX-(Math.cos(ang)*distanceToOrigin)*scaleX
    point[1] = originY-(Math.sin(ang)*distanceToOrigin)*scaleY
    lineString.pushPoint({lat: point[0], lng: point[1]})
    path = new H.map.Polyline(
        lineString, { style: { lineWidth: 4,
            strokeColor: '#2600ff' }}
    )
    LineStrings.push([path, nestedFloor[heading[0]]])
    nestedFloor[heading[0]].addObject(path);//displays the route on the map
}

function suggestionList(e, className, searchBar, option){
    let userInput = (e.target.value);
    var flatArray = [].concat.apply([], roomsList);
    let emptyArray = Object.assign([], flatArray); 
    
    if(userInput){
        emptyArray = emptyArray.filter((data) =>{
            return data.startsWith(userInput)
        })
        emptyArray.forEach((data, index) => {
            emptyArray[index] = '<li>Room ' + data + '</li>';
        })
        showSuggestions(emptyArray, searchBar)
        let allList = suggestions.querySelectorAll('li');
        for (let i = 0; i < allList.length; i++){
            if (option == 1){
                allList[i].setAttribute('onclick', 'onSearchPress(this)')
            }if (option == 2){
                allList[i].setAttribute('onclick', 'onSearchPress2(this)')
            }
        }
        if(suggestions.classList.contains(className)==false){
            suggestions.classList.add(className)
        }
    }else{
        suggestions.classList.remove(className)
    }
}

function showSuggestions(list, searchBar){
    let listData;
    if(!list.length){
        listData = '<li>' + searchBar.value + '<li>' ;
    }else{
        list = list.slice(0, 4);
        listData = list.join(' ');
    }
    suggestions.innerHTML = listData;
    
}

function onSearchPress(roomName){
    var searchBar = document.getElementById('search')
    roomName = roomName.textContent;
    searchBar.value = roomName;
    document.getElementById('Dest').value=roomName;
    suggestions.classList.remove('suggestions-active')
    dir.classList.toggle('dir-active');
}

function onSearchPress2(roomName){
    var startEntry = document.getElementById('startL')
    roomName = roomName.textContent;
    startEntry.value = roomName;
    suggestions.classList.remove('suggestions-active-dir')
}

function checkBtn(BtnID, floor) {

    BtnID.addEventListener('click', () => {
        map.removeObject(current)
        map.addObject(floor)
        current = floor
        currentBtn.style.backgroundColor = '#e2e2e2';
        BtnID.style.backgroundColor = '#8d8c8c'
        currentBtn = BtnID
    });
}

function changeFloor(newFloor){
    map.removeObject(current)
    map.addObject(newFloor)
    current = newFloor
}


function readTextFile(file, callback) {
    var rawFile = new XMLHttpRequest();
    rawFile.overrideMimeType("application/json");
    rawFile.open("GET", file, true);
    rawFile.onreadystatechange = function() {
        if (rawFile.readyState === 4 && rawFile.status == "200") {
            callback(rawFile.responseText);
        }
    }
    rawFile.send(null);
}

function pythagorean(sideA, sideB){
    return Math.sqrt(Math.pow(sideA, 2) + Math.pow(sideB, 2));
}

function addPolygonToMap(map, x1, y1, x2, y2, x3, y3, x4, y4, colour, floor, counter) {
    var geoPolygon = new H.geo.Polygon(
        // define exterior shape
        new H.geo.LineString([x1, y1, 0, x2, y2, 0, x3, y3, 0, x4, y4, 0]),
    );

    geoPolygon = new H.map.Polygon(geoPolygon, {
        style: {
            fillColor: colour,
            strokeColor: '#000000',
            lineWidth: 1
        }
        })

    geoPolygon.addEventListener('tap', function(evt) {
        // Log 'tap' and 'mouse' events:
        const nav = document.querySelector('.x');
        var roomInf = document.getElementById('room')
        var heading = document.getElementById('room-header')
        
        heading.innerHTML = 'Room ' + counter;
        point = nestedRooms[counter[0]][counter][0]
        var point = Object.assign({}, point);
        var distanceToOrigin = pythagorean(point[1], point[0])//maths
        var ang = 1.5708-(angle + Math.atan(point[0]/point[1]))
        point[0] = originX-(Math.cos(ang)*distanceToOrigin)*scaleX
        point[1] = originY-(Math.sin(ang)*distanceToOrigin)*scaleY
        roomMarker = new H.map.Marker({lat: point[0], lng: point[1]})
        current.addObject(roomMarker)
        roomInf.classList.toggle('room-active');
        click = 1;
        if (nav.classList.contains('nav-active')==true){
            nav.classList.toggle('nav-active');
        }
    });

    floor.addObject(geoPolygon);
}



function readFile(filename, floor, colour) {
    readTextFile(filename, function(text){
        const data = JSON.parse(text);
        var counter = 0;
        for (const i in data) {
            const list = [];
    
            list.push(data[i].C1, data[i].C2, data[i].C3, data[i].C4);
    
            
    
            for (const j in list) {
                var distanceToOrigin = pythagorean(list[j][1], list[j][0])
                var ang = 1.5708-(angle + Math.atan(list[j][0]/list[j][1]))
                
                list[j][0] = originX-(Math.cos(ang)*distanceToOrigin)*scaleX
                list[j][1] = originY-(Math.sin(ang)*distanceToOrigin)*scaleY
            }
    
            addPolygonToMap(map, (list[0][0]), (list[0][1]), (list[1][0]), (list[1][1]), (list[2][0]), (list[2][1]), (list[3][0]), (list[3][1]), colour, floor, data[i].RoomName)
            counter += 1
        }
    });
}




var platform = new H.service.Platform({
    apikey: 'AVQH9aq2YITVAneHl43rMLelMoKrugq__qtoduaRKkU'
    });

var defaultLayers = platform.createDefaultLayers();

var map = new H.Map(document.getElementById('map'),
defaultLayers.vector.normal.map,{
center: {lat:53.4717, lng:-2.2398},
zoom: 18,
pixelRatio: window.devicePixelRatio || 1

});
// add a resize listener to make sure that the map occupies the whole container
window.addEventListener('resize', () => map.getViewPort().resize());

// MapEvents enables the event system
// Behavior implements default interactions for pan/zoom (also on mobile touch environments)
var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));

// var listOfCoords = [];

// map.addEventListener('tap', function (evt) {
//     var coord = map.screenToGeo(evt.currentPointer.viewportX,
//             evt.currentPointer.viewportY);
    
//     listOfCoords.push(coord.lat, coord.lng)

//     // logEvent('Clicked at ' + Math.abs(coord.lat.toFixed(4)) +
//     //     ((coord.lat > 0) ? 'N' : 'S') +
//     //     ' ' + Math.abs(coord.lng.toFixed(4)) +
//     //      ((coord.lng > 0) ? 'E' : 'W'));
//   });

var ui = H.ui.UI.createDefault(map, defaultLayers);

// // 53.47214222925153
// 1 -2.239124083328247
// 2 53.47208794865287
// 3 -2.239247464942932
// 4 53.47231464951621
// 5 -2.239472770500183
// 6 53.47221886056675
// 7 -2.2397624490737917
// 8 53.47216777303865
// 9 -2.23979463558197
// 10 53.47213265032742 
// 11 -2.239896559524536

const lineString = new H.geo.LineString();


function eachFn(lat, lng, alt, idx) {
    lineString.removePoint({lat:lat, lng:lng})
  }



const scaleX = 0.000000107;
const scaleY = 0.000000171;
const originX = 53.4724642;
const originY = -2.2393615;
var click = 0;
var angle = 0.484;
var path;
var currentBtn = document.getElementById('F0');


var F0 = new H.map.Group()
var F1 = new H.map.Group()
var F2 = new H.map.Group()
var F3 = new H.map.Group()
var F4 = new H.map.Group()
var Rooms0 = {}
var Rooms1 = {}
var Rooms2 = {}
var Rooms3 = {}
var Rooms4 = {}
var nestedRooms = []
var nestedFloor = []
var roomsList = [];
var LineStrings = [];
var roomMarker;

var current = F0;


function loadRoom(filename, Rooms){
    readTextFile(filename, function(text){
        const data = JSON.parse(text);
        for (const i in data) {
            Rooms[data[i]['RoomName']] = [data[i]['Coordinates'], data[i]['Links']];
        }
    
        roomsList.push(Object.keys(Rooms));
    })
}



loadRoom('Floor1Rooms0.json', Rooms0)
loadRoom('Floor1Rooms.json', Rooms1)
loadRoom('Floor1Rooms2.json', Rooms2)
loadRoom('Floor1Rooms3.json', Rooms3)
loadRoom('Floor1Rooms4.json', Rooms4)

nestedRooms = [Rooms0, Rooms1, Rooms2, Rooms3, Rooms4]
nestedFloor = [F0, F1, F2, F3, F4]

readFile("resultTest0.json", F0, 'rgba(255, 255, 200, 1)')
readFile("resultTest.json", F1, 'rgba(255, 255, 200, 1)')
readFile("resultTest2.json", F2, 'rgba(255, 255, 200, 1)')
readFile("resultTest3.json", F3, 'rgba(255, 255, 200, 1)')
readFile("resultTest4.json", F4, 'rgba(255, 255, 200, 1)')


map.addObject(F0)

navSlide();
